import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import { StyleSheet,
    Button,
    View,
    SafeAreaView,
    Text,
    Alert, } from 'react-native';

const RegisterButton = (props) => {
  return (
    <Button
     onPress={() =>navigation.navigate('Profile', {name: 'Jane'})}
     title="Register"
     color="#000000"
    accessibilityLabel="Press to Register"
    />
  );
};

export default RegisterButton;