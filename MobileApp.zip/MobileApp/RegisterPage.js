import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, Alert, Button } from 'react-native';
import UsernameInput from './UsernameInput';
import PasswordInput from './PasswordInput';
import EmailInput from './EmailInput';
import FirstNameInput from './FirstNameInput';
import LastNameInput from './LastNameInput';
import LoginButton from './LoginButton';
import RegisterButton from './RegisterButton';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

const RegisterPage = ({navigation, route}) => {
    return (
      <View style={styles.container}>
        <View style={styles.subcontainer}>
        <View style={styles.logo}>
          <Image style={styles.logoimg} source={require('./assets/logo.png')}/>
        </View>
        <UsernameInput
          onChangeText={this.handleUsernameChange}
          style={styles.textInput}
        />
        <PasswordInput
          onChangeText={this.handleUsernameChange}
          style={styles.passwordInput}
        />
        <EmailInput
          onChangeText={this.handleUsernameChange}
          style={styles.textInput}
        />
        <FirstNameInput
          onChangeText={this.handleUsernameChange}
          style={styles.textInput}
        />
        <LastNameInput
          onChangeText={this.handleUsernameChange}
          style={styles.textInput}
        />
        
        <View style={styles.buttonContainer}>
          <Button 
            style={styles.button}
            title="Back"
            onPress={() =>
            navigation.navigate('LoginPage')}
            color="#000000"
            />
          <RegisterButton style={styles.button}/>
        </View>
  
        
      </View>
      </View>
    );
  };
  
  export default RegisterPage;
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100%',
      width: '100%',
    },
    subcontainer: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100%',
      width: '80%',
    },
  
    logo: {
      width: '100%',
      height: '30%',
      alignItems: 'center'
    },
  
    logoimg: {
      width: '100%',
      height: '35%',
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: '23%'
    },
  
    textInput: {
      borderWidth: 1,
      borderColor: 'black',
      borderRadius: 4,
      padding: 10,
      width: '100%',
      marginTop: '3%'
    },
  
    passwordInput: {
      borderWidth: 1,
      borderColor: 'black',
      borderRadius: 4,
      padding: 10,
      width: '100%',
      marginTop: '3%',
    },
  
    buttonContainer: {
      flexDirection: 'row',
      marginBottom: '30%',
      marginTop: 5,
      width: '100%',
      alignItems: 'center',
      justifyContent: 'space-around',
    },
  
    button: {
      backgroundColor: '#007aff',
      borderRadius: 5,
      padding: 10,
      marginHorizontal: 10,
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      height: '10%'
    },
  
    buttonText: {
      color: 'white',
      fontSize: 16,
      fontWeight: 'bold',
    },
  });